#include <iostream>

using namespace std;

int update(int a){
    a-=5;
    cout<<a<<endl;
    return a;
}

int main(){
    int a;
    cin>>a;
    update(a);
    cout<<a<<endl;
}
