#include<iostream>
#include<vector>
using namespace std;


    
int main() {
  
    int size,p,s,e,n,a;
    cin>>n;
    vector<int>v;
    for(int i=0;i<n;i++)
    {
        cin>>a;
        v.push_back(a);
    }
    
    
    cin>>p>>s>>e;
    v.erase(v.begin()+(p-1));
    v.erase(v.begin()+s-1,v.begin()+e-1);
    
    
    size=v.size();
    cout<< "size is->"<<size<<endl;
    for(int j=0;j<size;j++)
    {
        cout<<"vector is->"<<v[j]<<endl;
    }

    
    return 0;
}

