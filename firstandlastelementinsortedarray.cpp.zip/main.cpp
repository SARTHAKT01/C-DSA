#include<iostream>
using namespace std;


 int firstoccure( int arr[], int n, int key){
     int s=0;
     int e=n-1;
     int ans = -1;
     int mid= s+ (e-s)/2;
     
     while(s<=e){
         if(arr[mid]==key){
             ans=mid;
             e=e-1;
         }
         else if( arr[mid]>key){
             e=e-1;
         }
         else if( arr[mid]<key){
             s=mid+1;
         }
         mid= s+(e-s)/2;
     }
     return ans;
      }
      
int lastoccure( int arr[], int n, int key){
     int s=0;
     int e=n-1;
     int ans = -1;
     int mid= s+ (e-s)/2;
     
     while(s<=e){
         if(arr[mid]==key){
             ans=mid;
             s=mid+1;
         }
         else if( arr[mid]>key){
             e=e-1;
         }
         else if( arr[mid]<key){
             s=mid+1;
         }
         mid= s+(e-s)/2;
     }
     return ans;
      }
      
int main(){
      int arr[8]={1,2,3,4,5,5,6,7};
      int arrIndex=firstoccure(arr,8,5);
      int brrIndex=lastoccure(arr,8,5);
      
      cout<<" index of first occure  "<<arrIndex<<endl;
      cout<<" index of last occure   "<<brrIndex<<endl;
      
      int sum=(brrIndex-arrIndex)+1;
      
      cout<<"no. of time it occure  "<<sum<<endl;
        return 0;
    }
      
 