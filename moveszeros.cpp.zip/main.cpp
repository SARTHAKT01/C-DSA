#include<iostream>
#include<vector>
using namespace std;

vector<int>moveZeros(vector<int>v){
    int nonzero=0;
    for(int j=0;j<v.size();j++){
        if(v[j]!=0){
            swap(v[j],v[nonzero]);
            nonzero++;
    }
 
    
}
   return v;
}


void print(vector<int> v){
    int i;
    for(int i=0;i<v.size();i++){
        cout<<v[i]<<"";
    }
    cout<<endl;
}



int main(){
    
    
    vector<int>v;
    
    v.push_back(0);
    v.push_back(0);
    v.push_back(7);
    v.push_back(9);
    v.push_back(0);
    
    
    
    vector<int> ans=moveZeros(v);
    
    cout<<"printing the array"<<endl;
    print(ans);
    return 0;
}
