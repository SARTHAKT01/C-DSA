#include<iostream>
#include<stack>
using namespace std;

int main(){
    stack<string>s;
    
    s.push("sarthak");
    
    s.push("ram");
    
    s.push("jack");
    
    s.push("amar");
    
    
    cout<<"top element->"<<s.top()<<endl;

}