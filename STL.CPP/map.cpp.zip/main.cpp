#include <iostream>
#include<map>
using namespace std;
int main(){
    map<int,string>m;
    
    m[1]="ram";
    m[2]="lakhan";
    m[3]="jack";
    m[4]="amar";
    
    m.insert({5,"bheem"});\
    for(auto i:m){
        cout<<i.first<<""<<i.second<<endl;
    }
    m.erase(2);
    for(auto i:m){
        cout<<i.first<<""<<i.second<<endl;
    }
}