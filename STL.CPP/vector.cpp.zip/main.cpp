#include<iostream>
#include<vector>

using namespace std;

int main(){

vector<int>v;
int size=v.size();

cout<<"capacity->"<<v.capacity()<<endl;

v.push_back(1);
cout<<"capacity->"<<v.capacity()<<endl;

v.push_back(2);
cout<<"capacity->"<<v.capacity()<<endl;


v.push_back(6);
cout<<"size->"<<v.size()<<endl;
cout<<"capacity->"<<v.capacity()<<endl;

cout<<"element at second index->"<<v.at(2)<<endl;

cout<<"first element-> "<<v.front()<<endl;
cout<<"last element->"<<v.back()<<endl;

cout<<"before pop"<<endl;
for(int i:v){
    cout<<i<<endl;
    
}

v.pop_back();

cout<<"after pop"<<endl;
for(int i:v){
    cout<<i<<endl;
}

cout<<"before clear size->"<<v.size()<<endl;
v.clear();
cout<<"after clear size->" <<v.size()<<endl;



}