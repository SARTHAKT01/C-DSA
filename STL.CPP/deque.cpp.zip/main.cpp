#include<iostream>
#include<deque>
using namespace std;

int main(){
    deque<int> d;
    d.push_back(1);
    d.push_back(2);
    d.push_back(4); 
    d.push_back(6);
    d.push_front(9);
    
    cout<<"element at second index->"<<d.at(0)<<endl;
    cout<<"empty or not->"<<d.empty( ) <<endl;
    cout<<"first element-> "<<d.front()<<endl;
    cout<<"last element->"<<d.back()<<endl;
    cout<<"size of array->"<<d.size()<<endl;
    
    
    
    for(int i:d){
        cout<<i<<endl;
        
    }
    
    
    d.pop_front();
    cout<<endl;
    for(int i:d){
        cout<<i<<endl;
        
    }
    
}