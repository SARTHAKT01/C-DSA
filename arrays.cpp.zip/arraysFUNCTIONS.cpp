/*#include <iostream>
using namespace std;
void printArray(int arr[], int size){
    cout<<"printing them the array"<<endl;
    for (int i =0; i<size;i++){
        cout<<arr[i]<<" ";
         }
         cout<<"printing done"<<endl;
         
    }
    int main(){
        int number[15]={2,7,5,6,7,4,3,2,6,9,8,7,6,6,7};
        int n=15;
        printArray(number,15);
        
    }
    */