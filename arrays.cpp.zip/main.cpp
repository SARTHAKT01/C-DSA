/*#include <iostream>
using namespace std;
int main(){
int arr[5] = {2,7};
int n=5;
for (int i=0;i<n;i++){
    cout<<arr[i]<<" ";
}
}
*/